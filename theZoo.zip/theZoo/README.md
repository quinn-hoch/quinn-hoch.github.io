###### Exercise - theZoo
The animals are running free around the zoo‼️

Download theZoo folder In terminal or Power Shell, using unix commands put all the animals in their proper places! And make sure to corral or forcibly remove the animal rights' activists. 

Building names inspired by old Philly Zoo titles. Find the contemporary language [here](https://philadelphiazoo.org/zoo-map/)

###### Unix Commands
```
pwd - “present working directory” - where am i in the system!?
ls - list everything in this directory 
cd - “change diretory [insert name of folder]” - 
.. -  goes back to the parent directory 
mkdir -  “make directory” - make a folder
rm- “remove file”- deletes a file forever (not the trash). doesn’t work on directories
mv -  “move” - move file (will also overwrite a file if: "mv file.txt renamedFile.txt)
      
```